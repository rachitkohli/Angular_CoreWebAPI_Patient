import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { IDesease } from './IDesease';
import { stringify } from 'querystring';

@Injectable({
  providedIn: 'root'
})
export class DiseaseService {
  private apiUrl = 'https://localhost:44347/api/Diseases';

  constructor(private http: HttpClient) {  }

  getDisease() : Observable<IDesease[]> {
    return this.http.get<IDesease[]>(this.apiUrl).pipe(
      tap(data => console.log('Disease from Service : ' + JSON.stringify(data)))
    ); 
  }


}
