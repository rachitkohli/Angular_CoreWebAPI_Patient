import { Component, OnInit, OnChanges } from '@angular/core';
import { DiseaseService } from './disease.service';
import { IDesease } from './IDesease';

@Component({
  selector: 'app-disease',
  templateUrl: './disease.component.html',
  styleUrls: ['./disease.component.css']
})
export class DiseaseComponent implements OnInit {
  deseaseList: IDesease[] = [];
 
  constructor(private diseaseService: DiseaseService) { }

  ngOnInit(): void {
    this.diseaseService.getDisease().subscribe (disease=> {
      this.deseaseList = disease;
      console.log("Component: " + this.deseaseList.length);
     }
    );   
  }

  clickme(code:string) { 
    // alert(code); 
   
  }

}
