export class IDesease {
    id: number;
    diseaseName: string;
    code: string;
    description: string;
}