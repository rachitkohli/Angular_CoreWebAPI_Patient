import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from './patient';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http: HttpClient) { }
  apiUrl = 'https://localhost:44347/api/Patientmodels/PatientQuery/';

  getPatientsByCode(code:String) : Observable<Patient[]> {
    return this.http.get<Patient[]>(this.apiUrl + code).pipe(
      tap(data => console.log('Patients From Service : ' + JSON.stringify(data)))
  ); 
}

}
