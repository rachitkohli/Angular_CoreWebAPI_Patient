import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from './patient.service';
import { Patient } from './patient';

@Component({
  selector: 'app-patients',
  templateUrl: './patients.component.html',
  styleUrls: ['./patients.component.css']
})
export class PatientsComponent implements OnInit, OnChanges {
  dcode:string;
  Patients: Patient[];

  constructor(private route: ActivatedRoute,
    private patientservice: PatientService) { }


  ngOnInit(): void {
    
    this.route.url.subscribe(url =>{
      let code = this.route.snapshot.paramMap.get('code');
      this.getPatientsByCode(code);
      this.dcode=code;
  });
  }

  ngOnChanges() : void{
    console.log("Patient change event!");
  }

  getPatientsByCode(strcode:string)
  {
    this.patientservice.getPatientsByCode(strcode).subscribe(
      p=>{this.Patients=p}
      
    );
    console.log(strcode);
  }

}
