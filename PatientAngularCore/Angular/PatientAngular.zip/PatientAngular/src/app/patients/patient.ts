export class Patient {
    mrn:string;
    firstname:string;
    lastname:string;
    age:number;
    sex:string;
    city:string;
    country:string;
}