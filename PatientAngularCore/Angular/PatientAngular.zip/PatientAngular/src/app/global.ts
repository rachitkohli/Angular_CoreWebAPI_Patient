export class globalvariables{
    globalcode:string;
}