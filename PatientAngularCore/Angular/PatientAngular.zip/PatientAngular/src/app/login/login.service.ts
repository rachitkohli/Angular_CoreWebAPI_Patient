import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { login } from './login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private  apiUrl= "https://localhost:44347/api/Users/Login";
  response:string;    
  constructor(private http: HttpClient) { }

  LogIn(_login:login):Observable<any> {
    const headers = new HttpHeaders().set('content-type', 'application/json');
    return this.http.post<string>(this.apiUrl, JSON.stringify(_login),{headers});
  }

}
