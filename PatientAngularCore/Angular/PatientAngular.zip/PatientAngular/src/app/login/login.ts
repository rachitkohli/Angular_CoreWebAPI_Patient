export class login {
    public id:number;
    public username:string ;
    public password: string;
    public UserId: string;
}