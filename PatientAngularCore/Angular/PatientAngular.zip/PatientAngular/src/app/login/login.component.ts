import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginService } from './login.service';
import { login } from './login';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string;
  password:string;
  private loginStatus:string;

  constructor(private loginservice: LoginService,
    private router: Router  ) { }
  errorMessage: string;
  ngOnInit(): void {
    
  }

  _dummy:login;
  logMeIn(userForm: NgForm) {
    console.log("UserName: " + userForm.value.username);
    this._dummy = new login();
    this._dummy.username = userForm.value.username;
    this._dummy.password = userForm.value.password;
    this.loginservice.LogIn(this._dummy).subscribe({
     // resp=>(resp.toString())
     next: s => this.storeResponse(s),
     error: err => console.log(err)}
    );
    // console.log(this.errorMessage);
  }

  storeResponse(a): void {
    console.log(a);
    this.loginStatus = a.response;
    console.log(this.loginStatus);
    localStorage.setItem('loginStatus', a.response);
    this.router.navigate(['/Patients']);
  }
}
