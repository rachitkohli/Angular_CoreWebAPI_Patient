import { Component, OnInit, Input } from '@angular/core';
import { PatientService } from '../patients/patient.service';
import { Patient } from '../patients/patient';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {
@Input() patientcode: string;
  Patients:Patient[];
  constructor(private patientservice: PatientService) { }

  ngOnInit(): void {
    
  }

  
}
